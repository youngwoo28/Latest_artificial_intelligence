# ✅ Ollama 배치 요약 + Slack 자동 전송 (형님 계정 버전)
# pip install pandas requests

import ollama
import pandas as pd
import requests
import json


import os
env_path = os.path.join(os.getcwd(), ".env")
load_dotenv(dotenv_path=env_path)

SLACK_TOKEN = os.getenv("SLACK_TOKEN")
CHANNEL_ID = os.getenv("CHANNEL_ID")

# 2️⃣ Ollama 요약 함수
def ask(model, task, system="한국어로 간결하고 정확하게 답해줘.", **options):
    return ollama.chat(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": task}
        ],
        options=options or {}
    )['message']['content']

# 3️⃣ 요약 대상 문단들
paragraphs = [
    "전자상거래에서는 고객지원 자동화가 중요한 과제로 부상했다. AI 챗봇과 검색 시스템이 핵심이다.",
    "검색결합형(RAG) 접근은 내부 문서를 참조하여 최신 정보를 제공한다. 기업 도입이 증가하고 있다.",
    "로컬 추론은 개인정보와 기밀문서 보호에 유리하다. Ollama 같은 도구가 이를 가능하게 한다."
]

# 4️⃣ 요약 수행
rows = []
for i, p in enumerate(paragraphs, start=1):
    summary = ask('gemma3:4b', f"두 문장으로 요약하고 핵심 키워드 3개를 해시태그로: {p}", temperature=0.2)
    rows.append({"id": i, "summary": summary})

df = pd.DataFrame(rows)

# 5️⃣ 표 형태 텍스트로 변환
table_text = "\n".join([f"{row.id}. {row.summary}" for row in df.itertuples()])

# 6️⃣ Slack 전송 메시지 구성
payload = {
    "channel": CHANNEL_ID,
    "text": f"🧠 **배치 문서 요약 결과**\n\n{table_text}",
    "username": "최영우",
    "icon_emoji": ":male-technologist:"
}
headers = {
    "Authorization": f"Bearer {SLACK_TOKEN}",
    "Content-Type": "application/json; charset=utf-8"
}

# 봇 자동 참가 (혹시 빠져있을 경우 대비)
try:
    requests.post("https://slack.com/api/conversations.join", headers=headers, json={"channel": CHANNEL_ID})
except Exception:
    pass

# 7️⃣ Slack 메시지 전송
response = requests.post("https://slack.com/api/chat.postMessage", headers=headers, json=payload)
result = response.json()

# 8️⃣ 결과 출력
if result.get("ok"):
    print("✅ Slack 전송 성공")
    print(f"채널: {result['channel']} | 메시지 ts: {result['ts']}")
else:
    print("❌ Slack 전송 실패:", json.dumps(result, ensure_ascii=False))
