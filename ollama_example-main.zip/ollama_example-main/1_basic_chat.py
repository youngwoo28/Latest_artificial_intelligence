# ✅ Ollama + Slack 자동 전송 (.env 파일 완전 호환)
import os
import json
import requests
import ollama
from dotenv import load_dotenv

# 1️⃣ .env 강제 로드 (현재 실행 경로 기준)
env_path = os.path.join(os.getcwd(), ".env")
load_dotenv(dotenv_path=env_path)

SLACK_TOKEN = os.getenv("SLACK_TOKEN")
CHANNEL_ID = os.getenv("CHANNEL_ID")




if not SLACK_TOKEN or not CHANNEL_ID:
    raise SystemExit(f"❌ .env 로드 실패 (경로: {env_path})")

# 2️⃣ Ollama 질의
resp = ollama.chat(
    model='gemma3:4b',
    messages=[
        {"role": "system", "content": "You are a concise Korean assistant."},
        {"role": "user", "content": "LangChain의 필요성을 한 문장으로 설명해줘."}
    ],
    options={"temperature": 0}
)
assistant_text = resp["message"]["content"]

# 3️⃣ Slack 전송
payload = {
    "channel": CHANNEL_ID,
    "text": f"LangChain 분석 결과 (자동 전송):\n\n{assistant_text}",
    "username": "최영우",
    "icon_emoji": ":male-technologist:"
}
headers = {
    "Authorization": f"Bearer {SLACK_TOKEN}",
    "Content-Type": "application/json; charset=utf-8"
}

response = requests.post("https://slack.com/api/chat.postMessage", headers=headers, json=payload)
result = response.json()

# 4️⃣ 결과 확인
if result.get("ok"):
    print("✅ Slack 전송 성공")
    print(f"채널: {result['channel']} | 메시지 ts: {result['ts']}")
else:
    print("❌ Slack 전송 실패:", json.dumps(result, ensure_ascii=False))
