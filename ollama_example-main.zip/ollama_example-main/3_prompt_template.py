# ✅ Ollama 프롬프트 함수 + Slack 자동 전송 (직접 토큰/채널 입력 버전)
import json
import requests
import ollama


import os
env_path = os.path.join(os.getcwd(), ".env")
load_dotenv(dotenv_path=env_path)

SLACK_TOKEN = os.getenv("SLACK_TOKEN")
CHANNEL_ID = os.getenv("CHANNEL_ID")
# 2️⃣ Ollama 프롬프트 함수 정의
def ask(model, task, system="한국어로 간결하고 정확하게 답해줘.", **options):
    resp = ollama.chat(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": task}
        ],
        options=options or {}
    )
    return resp["message"]["content"]

# 3️⃣ Ollama 호출
result_text = ask("gemma3:4b", "대한민국을 한 문장으로 설명해줘.")

# 4️⃣ Slack 메시지 전송
payload = {
    "channel": CHANNEL_ID,
    "text": f"🇰🇷 대한민국 요약 결과 (자동 전송):\n\n{result_text}",
    "username": "최영우",
    "icon_emoji": ":male-technologist:"
}

headers = {
    "Authorization": f"Bearer {SLACK_TOKEN}",
    "Content-Type": "application/json; charset=utf-8"
}

# 5️⃣ 채널 자동 참가 시도 (봇이 채널에 없을 때)
try:
    join_resp = requests.post(
        "https://slack.com/api/conversations.join",
        headers=headers,
        json={"channel": CHANNEL_ID}
    )
    _ = join_resp.json()
except Exception:
    pass  # 오류 무시하고 계속 진행

# 6️⃣ 메시지 전송
response = requests.post("https://slack.com/api/chat.postMessage", headers=headers, json=payload)
result = response.json()

# 7️⃣ 결과 출력
if result.get("ok"):
    print("✅ Slack 전송 성공")
    print(f"채널: {result['channel']} | 메시지 ts: {result['ts']}")
else:
    print("❌ Slack 전송 실패:", json.dumps(result, ensure_ascii=False))
    if result.get("error") == "not_in_channel":
        print(
            "ℹ️ 봇이 채널에 참가되어 있지 않습니다. 다음을 확인하세요:\n"
            "  1) 채널이 비공개면 봇을 직접 초대 (/invite @봇이름)\n"
            "  2) CHANNEL_ID가 실제 채널 ID인지 확인 (C로 시작)\n"
            "  3) 봇 토큰에 'chat:write'와 'conversations.join' 권한이 있는지 확인"
        )
