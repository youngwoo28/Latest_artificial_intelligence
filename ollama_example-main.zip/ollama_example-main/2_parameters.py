# ✅ Ollama → Slack 자동 전송 (.env에서 토큰+채널ID 불러오기)
import os
import json
import requests
import ollama
from dotenv import load_dotenv

# 1️⃣ .env 로드
load_dotenv()

# 2️⃣ 환경변수 읽기
SLACK_TOKEN = os.getenv("SLACK_TOKEN")
CHANNEL_ID = os.getenv("CHANNEL_ID")

if not SLACK_TOKEN or not CHANNEL_ID:
    raise SystemExit("❌ .env 파일에 SLACK_TOKEN 또는 CHANNEL_ID가 누락되었습니다.")

# 3️⃣ Ollama 옵션 설정
options = {
    "temperature": 0.2,
    "num_ctx": 4096,
    "num_predict": 256
}

# 4️⃣ Ollama 질의
resp = ollama.chat(
    model="gemma3:4b",
    messages=[{"role": "user", "content": "한 문단짜리 한국어 격언을 창의적으로 지어줘."}],
    options=options
)
assistant_text = resp["message"]["content"]

# 5️⃣ Slack 메시지 전송
payload = {
    "channel": CHANNEL_ID,
    "text": (
        "🔥 Ollama 파라미터 테스트 결과 🔥\n"
        f"temperature: {options['temperature']}\n"
        f"num_ctx: {options['num_ctx']}\n"
        f"num_predict: {options['num_predict']}\n\n"
        f"🧠 생성된 격언:\n{assistant_text}"
    ),
    "username": "최영우",
    "icon_emoji": ":male-technologist:"
}

headers = {
    "Authorization": f"Bearer {SLACK_TOKEN}",
    "Content-Type": "application/json; charset=utf-8"
}

response = requests.post("https://slack.com/api/chat.postMessage", headers=headers, json=payload)
result = response.json()

# 6️⃣ 결과 확인
if result.get("ok"):
    print("✅ Slack 전송 성공")
    print(f"채널: {result['channel']} | 메시지 ts: {result['ts']}")
else:
    print("❌ Slack 전송 실패:", json.dumps(result, ensure_ascii=False))
