# ✅ Ollama 구조화 JSON 추출 + Slack 자동 전송 (직접 토큰/채널 버전)
import json
import requests
import ollama

import os
env_path = os.path.join(os.getcwd(), ".env")
load_dotenv(dotenv_path=env_path)

SLACK_TOKEN = os.getenv("SLACK_TOKEN")
CHANNEL_ID = os.getenv("CHANNEL_ID")
# 2️⃣ Ollama 1단계: 주문 데이터 JSON 추출
text = """
주문 3건:
1) 상품: 무선마우스, 수량 2, 가격 25,000원
2) 상품: 기계식 키보드, 수량 1, 가격 89,000원
3) 상품: USB-C 케이블, 수량 3, 가격 9,900원
총 배송지는 서울시 강남구 테헤란로 1
"""

prompt = f"""
아래 텍스트에서 주문 항목을 JSON으로 추출해.
스키마:
{{
  "orders":[{{"item":str,"qty":int,"price_krw":int}}],
  "shipping_address": str,
  "total_price_krw": int
}}
텍스트:
{text}
반드시 JSON만 출력.
"""

resp = ollama.chat(
    model='gemma3:4b',
    messages=[{"role": "user", "content": prompt}],
    format='json',
    options={"temperature": 0}
)

data = json.loads(resp['message']['content'])
result_1 = json.dumps(data, indent=2, ensure_ascii=False)

# 3️⃣ Ollama 2단계: 영화 리뷰 JSON 추출
review_text = """
크리스토퍼 놀란 감독의 '인터스텔라'는 SF 장르의 걸작이다. 
시각 효과가 정말 환상적이고, 한스 짐머의 음악이 영화와 완벽하게 어우러진다.
스토리도 감동적이며 과학적 고증도 뛰어나다.
다만 러닝타임이 169분으로 너무 길고, 일부 과학 설명이 일반 관객에게는 어렵게 느껴질 수 있다.
그럼에도 불구하고 꼭 봐야 할 영화다. 5점 만점에 4.5점을 주고 싶다.
"""

review_prompt = f"""
아래 영화 리뷰 텍스트에서 정보를 추출하여 JSON으로 출력해줘.

스키마:
{{
  "title": str,
  "director": str,
  "genre": str,
  "rating": float,
  "pros": [str],
  "cons": [str],
  "recommended": bool
}}

리뷰 텍스트:
{review_text}

반드시 JSON만 출력하고, 텍스트에서 유추 가능한 모든 정보를 포함해줘.
"""

review_resp = ollama.chat(
    model='gemma3:4b',
    messages=[{"role": "user", "content": review_prompt}],
    format='json',
    options={"temperature": 0}
)

review_data = json.loads(review_resp['message']['content'])
result_2 = json.dumps(review_data, indent=2, ensure_ascii=False)

# 4️⃣ Slack 메시지 전송
summary_message = (
    "📦 *주문 데이터 분석 결과*\n"
    f"```json\n{result_1}\n```\n\n"
    "🎬 *영화 리뷰 분석 결과*\n"
    f"```json\n{result_2}\n```"
)

payload = {
    "channel": CHANNEL_ID,
    "text": summary_message,
    "username": "최영우",
    "icon_emoji": ":male-technologist:"
}

headers = {
    "Authorization": f"Bearer {SLACK_TOKEN}",
    "Content-Type": "application/json; charset=utf-8"
}

# 5️⃣ 채널 자동 참가 시도 (봇이 빠져있으면)
try:
    requests.post("https://slack.com/api/conversations.join", headers=headers, json={"channel": CHANNEL_ID})
except Exception:
    pass

# 6️⃣ 메시지 전송
response = requests.post("https://slack.com/api/chat.postMessage", headers=headers, json=payload)
result = response.json()

# 7️⃣ 결과 확인
if result.get("ok"):
    print("✅ Slack 전송 성공")
    print(f"채널: {result['channel']} | 메시지 ts: {result['ts']}")
else:
    print("❌ Slack 전송 실패:", json.dumps(result, ensure_ascii=False))
    if result.get("error") == "not_in_channel":
        print(
            "ℹ️ 봇이 채널에 참가되어 있지 않습니다.\n"
            "  1) 비공개 채널이면 /invite @봇이름 으로 초대 필요\n"
            "  2) CHANNEL_ID 확인 필요\n"
            "  3) 'chat:write', 'conversations.join' 권한 확인 필요"
        )
