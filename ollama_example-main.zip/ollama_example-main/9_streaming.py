# ✅ 미니 RAG (FAISS + Ollama) + Slack 자동 전송 (형님 계정 완전 버전)
# 준비 명령:
#   ollama pull nomic-embed-text
#   pip install faiss-cpu numpy requests

import ollama
import requests
import numpy as np
import faiss
from typing import List

import os
env_path = os.path.join(os.getcwd(), ".env")
load_dotenv(dotenv_path=env_path)

SLACK_TOKEN = os.getenv("SLACK_TOKEN")
CHANNEL_ID = os.getenv("CHANNEL_ID")
# 2️⃣ Ollama 응답 함수
def ask(model, task, system="한국어로 간결하고 정확하게 답해줘.", **options):
    return ollama.chat(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": task}
        ],
        options=options or {}
    )['message']['content']

# 3️⃣ 문서 데이터
docs = [
    "LangChain은 LLM을 외부 데이터/툴과 연결하는 프레임워크다.",
    "Ollama는 로컬에서 LLM을 쉽게 돌릴 수 있게 해주는 런타임이다.",
    "RAG는 검색 결과를 LLM 프롬프트에 주입해 최신/사내 지식을 활용한다.",
    "Gemma3 4B는 가벼운 로컬 추론에 적합한 중소형 모델이다."
]

# 4️⃣ 임베딩 함수
def embed_texts(texts: List[str]) -> np.ndarray:
    vecs = []
    for t in texts:
        e = ollama.embeddings(model='nomic-embed-text', prompt=t)
        vecs.append(np.array(e['embedding'], dtype='float32'))
    return np.vstack(vecs)

# 5️⃣ 벡터화 및 색인
doc_vecs = embed_texts(docs)
faiss.normalize_L2(doc_vecs)
index = faiss.IndexFlatIP(doc_vecs.shape[1])
index.add(doc_vecs)

# 6️⃣ 검색 함수
def retrieve(query, k=2):
    qv = embed_texts([query])
    faiss.normalize_L2(qv)
    D, I = index.search(qv, k)
    return [docs[i] for i in I[0]]

# 7️⃣ RAG 기반 답변 생성
def rag_answer(question):
    ctx = "\n".join(retrieve(question, k=3))
    prompt = f"""
아래 컨텍스트를 참고해 질문에 한국어로 답해줘.
컨텍스트:
{ctx}

질문: {question}
답변은 간결하지만 정확하게.
"""
    return ask('gemma3:4b', prompt, temperature=0)

# 8️⃣ 질의 및 결과
question = "RAG가 왜 필요한가요?"
answer = rag_answer(question)

# 9️⃣ Slack 전송
payload = {
    "channel": CHANNEL_ID,
    "text": f"🧩 **Mini RAG 질의 응답 결과**\n\n❓질문: {question}\n\n💡답변:\n{answer}",
    "username": "최영우",
    "icon_emoji": ":male-technologist:"
}
headers = {
    "Authorization": f"Bearer {SLACK_TOKEN}",
    "Content-Type": "application/json; charset=utf-8"
}

# 채널 참가 (봇이 빠진 경우 대비)
try:
    requests.post("https://slack.com/api/conversations.join", headers=headers, json={"channel": CHANNEL_ID})
except Exception:
    pass

response = requests.post("https://slack.com/api/chat.postMessage", headers=headers, json=payload)
result = response.json()

# 10️⃣ 결과 출력
if result.get("ok"):
    print("✅ Slack 전송 성공")
    print(f"채널: {result['channel']} | 메시지 ts: {result['ts']}")
else:
    print("❌ Slack 전송 실패:", result)
