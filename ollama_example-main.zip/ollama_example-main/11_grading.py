# ✅ Ollama 루브릭 채점 + Slack 자동 전송 (형님 계정 버전)
import ollama
import json
import requests


import os
env_path = os.path.join(os.getcwd(), ".env")
load_dotenv(dotenv_path=env_path)

SLACK_TOKEN = os.getenv("SLACK_TOKEN")
CHANNEL_ID = os.getenv("CHANNEL_ID")

# 2️⃣ Ollama 응답 함수
def ask(model, task, system="한국어로 간결하고 정확하게 답해줘.", **options):
    return ollama.chat(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": task}
        ],
        options=options or {}
    )["message"]["content"]

# 3️⃣ 학생 답변 생성
student_answer = ask("gemma3:4b", "RAG의 정의를 한 문장으로 설명해줘.", temperature=0)

# 4️⃣ 채점 프롬프트
rubric = f"""
채점 기준:
1) 정의의 정확성(0~4)
2) 간결성(0~3)
3) 핵심 용어 사용(0~3)
총점=10, JSON으로만 출력: {{"score": <0-10>, "feedback": "<한줄 피드백>"}}

학생 답변:
{student_answer}
"""

# 5️⃣ Ollama 채점 수행
grade_resp = ollama.chat(
    model="gemma3:4b",
    messages=[{"role": "user", "content": rubric}],
    format="json",
    options={"temperature": 0}
)
grade_data = json.loads(grade_resp["message"]["content"])

# 6️⃣ Slack 전송 메시지 구성
summary_text = (
    f"🧑‍🎓 **RAG 정의 채점 결과**\n"
    f"🗣️ 학생 답변: {student_answer}\n\n"
    f"📊 점수: {grade_data['score']} / 10\n"
    f"💬 피드백: {grade_data['feedback']}"
)

payload = {
    "channel": CHANNEL_ID,
    "text": summary_text,
    "username": "최영우",
    "icon_emoji": ":male-teacher:"
}

headers = {
    "Authorization": f"Bearer {SLACK_TOKEN}",
    "Content-Type": "application/json; charset=utf-8"
}

# 7️⃣ Slack 메시지 전송
try:
    requests.post("https://slack.com/api/conversations.join", headers=headers, json={"channel": CHANNEL_ID})
except Exception:
    pass

response = requests.post("https://slack.com/api/chat.postMessage", headers=headers, json=payload)
result = response.json()

# 8️⃣ 실행 결과 출력
if result.get("ok"):
    print("✅ Slack 전송 성공")
    print(f"채널: {result['channel']} | 메시지 ts: {result['ts']}")
else:
    print("❌ Slack 전송 실패:", json.dumps(result, ensure_ascii=False))
