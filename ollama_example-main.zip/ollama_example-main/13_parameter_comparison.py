# ✅ Ollama 파라미터 비교 + Slack 요약 전송 (형님 계정 버전)
import ollama
import time
import requests
import json


import os
env_path = os.path.join(os.getcwd(), ".env")
load_dotenv(dotenv_path=env_path)

SLACK_TOKEN = os.getenv("SLACK_TOKEN")
CHANNEL_ID = os.getenv("CHANNEL_ID")
# 2️⃣ Ollama 비교 함수
def compare_responses(model, prompt, configs, title=""):
    """여러 설정으로 같은 프롬프트 실행하고 결과 비교"""
    print("\n" + "=" * 80)
    print(f"{title}")
    print("=" * 80)
    print(f"프롬프트: {prompt}")
    print("-" * 80)

    results = []
    for config in configs:
        print(f"\n[설정: {config['name']}]")
        for key, value in config["options"].items():
            print(f"  {key}: {value}")

        start_time = time.time()
        resp = ollama.chat(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            options=config["options"],
        )
        elapsed = time.time() - start_time

        result = resp["message"]["content"]
        print(f"\n응답 (소요시간: {elapsed:.2f}초):")
        print(result)
        print("-" * 80)

        results.append({
            "name": config["name"],
            "result": result,
            "time": elapsed,
        })

    return results


# 3️⃣ 테스트 구성 (Temperature 비교 예시)
temp_configs = [
    {"name": "Temperature 0.0 (최소)", "options": {"temperature": 0.0, "num_predict": 100}},
    {"name": "Temperature 0.5 (보통)", "options": {"temperature": 0.5, "num_predict": 100}},
    {"name": "Temperature 1.0 (높음)", "options": {"temperature": 1.0, "num_predict": 100}},
]

results = compare_responses(
    "gemma3:4b",
    "혁신적인 스마트폰 앱 아이디어를 하나 제안해줘.",
    temp_configs,
    "Temperature 비교 - 창의성 테스트",
)

# 4️⃣ Slack 메시지 구성 (요약본)
summary_lines = []
for r in results:
    summary_lines.append(f"• *{r['name']}* → {r['result'][:80]}...")

summary_text = (
    "🌡️ **Temperature 비교 결과 (자동 전송)**\n\n"
    + "\n".join(summary_lines)
)

payload = {
    "channel": CHANNEL_ID,
    "text": summary_text,
    "username": "최영우",
    "icon_emoji": ":male-technologist:",
}
headers = {
    "Authorization": f"Bearer {SLACK_TOKEN}",
    "Content-Type": "application/json; charset=utf-8",
}

# 봇 자동 참가 시도
try:
    requests.post("https://slack.com/api/conversations.join", headers=headers, json={"channel": CHANNEL_ID})
except Exception:
    pass

# 5️⃣ Slack 전송
response = requests.post("https://slack.com/api/chat.postMessage", headers=headers, json=payload)
result = response.json()

if result.get("ok"):
    print("\n✅ Slack 전송 성공")
    print(f"채널: {result['channel']} | 메시지 ts: {result['ts']}")
else:
    print("\n❌ Slack 전송 실패:", json.dumps(result, ensure_ascii=False))
