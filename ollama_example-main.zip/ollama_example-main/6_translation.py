# ✅ Ollama 번역(Translation) + Slack 자동 전송 (직접 토큰 버전)
import requests
import ollama


import os
env_path = os.path.join(os.getcwd(), ".env")
load_dotenv(dotenv_path=env_path)

SLACK_TOKEN = os.getenv("SLACK_TOKEN")
CHANNEL_ID = os.getenv("CHANNEL_ID")
# 2️⃣ Ollama 요청 함수
def ask(model, task, system="한국어로 간결하고 정확하게 답해줘.", **options):
    resp = ollama.chat(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": task}
        ],
        options=options or {}
    )
    return resp["message"]["content"]

# 3️⃣ 번역 대상 문장
english = """
We propose a lightweight retrieval-augmented pipeline for customer support emails.
The system combines semantic search with local LLM inference to provide accurate responses.
"""

prompt = f"""
다음 영어 문단을 '대학 강의노트' 스타일의 한국어로 번역해줘.
필요하면 용어를 각주 형식으로 보충 설명 (각주는 괄호로).
텍스트:
{english}
"""

# 4️⃣ Ollama 번역 실행
translation = ask('gemma3:4b', prompt, temperature=0.2)

# 5️⃣ Slack 전송
payload = {
    "channel": CHANNEL_ID,
    "text": f"🌐 **번역 결과 (대학 강의노트 스타일)**\n\n{translation}",
    "username": "최영우",
    "icon_emoji": ":male-technologist:"
}

headers = {
    "Authorization": f"Bearer {SLACK_TOKEN}",
    "Content-Type": "application/json; charset=utf-8"
}

# 6️⃣ 채널 참가 시도
try:
    requests.post("https://slack.com/api/conversations.join", headers=headers, json={"channel": CHANNEL_ID})
except Exception:
    pass

# 7️⃣ 메시지 전송
response = requests.post("https://slack.com/api/chat.postMessage", headers=headers, json=payload)
result = response.json()

# 8️⃣ 결과 출력
if result.get("ok"):
    print("✅ Slack 전송 성공")
    print(f"채널: {result['channel']} | 메시지 ts: {result['ts']}")
else:
    print("❌ Slack 전송 실패:", result)
