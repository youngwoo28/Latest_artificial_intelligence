# ✅ Ollama 감정 분류(Classification) + Slack 자동 전송 (직접 토큰 버전)
import json
import requests
import ollama


import os
env_path = os.path.join(os.getcwd(), ".env")
load_dotenv(dotenv_path=env_path)

SLACK_TOKEN = os.getenv("SLACK_TOKEN")
CHANNEL_ID = os.getenv("CHANNEL_ID")
# 2️⃣ 분류 대상 리뷰
reviews = [
    "배송이 빠르고 포장도 안전했어요.",
    "설명과 다른 제품이 왔고 반품 진행이 너무 느렸습니다.",
    "가격은 좋지만 내구성이 아쉽네요."
]

label_set = ["positive", "neutral", "negative"]
results = []

# 3️⃣ Ollama 분류 수행
for r in reviews:
    prompt = f"""
아래 리뷰를 {label_set} 중 하나로 분류하고, 한 문장 근거를 제시해.
JSON만 출력:
{{"label": <label>, "reason": <string>}}
리뷰: "{r}"
"""
    out = ollama.chat(
        model='gemma3:4b',
        messages=[{"role": "user", "content": prompt}],
        format='json',
        options={"temperature": 0}
    )
    data = json.loads(out['message']['content'])
    results.append({"review": r, **data})

# 4️⃣ Slack 메시지 내용 구성
summary_text = "🧾 **리뷰 감정 분류 결과**\n\n"
for i, res in enumerate(results, 1):
    summary_text += (
        f"{i}. 🗣️ *리뷰:* {res['review']}\n"
        f"   ➤ 라벨: `{res['label']}`\n"
        f"   💬 근거: {res['reason']}\n\n"
    )

# 5️⃣ Slack 전송
payload = {
    "channel": CHANNEL_ID,
    "text": summary_text,
    "username": "최영우",
    "icon_emoji": ":male-technologist:"
}
headers = {
    "Authorization": f"Bearer {SLACK_TOKEN}",
    "Content-Type": "application/json; charset=utf-8"
}

# 채널 자동 참가 시도 (봇이 빠져있을 경우)
try:
    requests.post("https://slack.com/api/conversations.join", headers=headers, json={"channel": CHANNEL_ID})
except Exception:
    pass

response = requests.post("https://slack.com/api/chat.postMessage", headers=headers, json=payload)
result = response.json()

# 6️⃣ 결과 출력
if result.get("ok"):
    print("✅ Slack 전송 성공")
    print(f"채널: {result['channel']} | 메시지 ts: {result['ts']}")
else:
    print("❌ Slack 전송 실패:", result)
